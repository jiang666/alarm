package com.example.alarm.bean

data class Person(var name:String) {
    var age:Int = 0
}