# alarm
知识点
version 1.1
添加字体和RecycleView S形显示。

version2.2
添加字体和RecycleView点击item特殊显示

随机数
Random rand = new Random();
Log.e("=======","mainEdit click " + rand.nextInt(10));

ivArrow.measure(0, 0);
int textWidth = ivArrow.getMeasuredWidth();
Log.e("======"," textWidth " + textWidth);